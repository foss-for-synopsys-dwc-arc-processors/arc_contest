# Save Your Ass

## Introduction
This is the flutter app for monitoring the sitting pose.

## Setup
Clon down the project and run the app. User should set up the [Firebase](https://firebase.google.com/) project before using the app.
