package com.example.save_your_ass

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
