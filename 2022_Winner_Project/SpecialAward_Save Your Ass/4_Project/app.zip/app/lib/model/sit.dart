import 'package:charts_flutter/flutter.dart' as charts;

class Sit {
  final String type;
  final double hour;
  final charts.Color color;
  Sit(this.type, this.hour, this.color);
}