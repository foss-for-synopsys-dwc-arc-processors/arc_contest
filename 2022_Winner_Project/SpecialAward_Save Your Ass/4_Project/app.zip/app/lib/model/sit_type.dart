class SitType {
  final String typeName;
  final double percent;
  SitType(this.typeName, this.percent);
}